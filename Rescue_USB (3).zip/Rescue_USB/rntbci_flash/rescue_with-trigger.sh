#!/usr/bin/env bash
set -Eeuo pipefail
# ----- CONFIG -----
# Respect existing CI_PROJECT_DIR (GitLab runner) otherwise default to PWD
CI_PROJECT_DIR="${CI_PROJECT_DIR:-$PWD}"
RESCUE_SCRIPT="$CI_PROJECT_DIR/rescue_trig.sh"
TRIGGER_SUBSTR="USB event listeners thread launched"
ALT_TRIGGER_SUBSTR="Waiting for USB Stick to be disconnected"
SERIAL_CAPTURE_LOG="$CI_PROJECT_DIR/rescue_serial.log"    # captured output of rescue.sh
ROBOT_LOG="$CI_PROJECT_DIR/robot_output.log"              # robot output (hidden from CI stdout)
TC_FILE="/opt/rfw/ccs3/tests/EMULATED/mch_switch/TC_MULTIVERSE_CONNECT_USB_TO_CDC.robot"
TC_FILE1="/opt/rfw/ccs3/tests/EMULATED/mch_switch/TC_MULTIVERSE_CONNECT_USB_TO_PC.robot"

USB_STICK_ID="087E-274D"
USB_STICK_MCH_PORT_ID="1"
USB_STICK_PORT_ID="2"
PHONE_USB_PORT_ID="4"

USB_STICK_ID="${USB_STICK_ID:-}"
TC_FILE="${TC_FILE:-}"
ADB_DEVICE_ID="${ADB_DEVICE_ID:-}"
DOWNLOAD_CHECK_PATH="/tmp/UsbUpdaterManager.log"

# PID of the main script so background watchers can signal it
MAIN_PID=$$
# File where watcher writes the post-micom result code (0=success, non-zero=failure)
RESULT_FILE="$CI_PROJECT_DIR/micom_result"

# Handler: when watcher finishes post-micom checks it will send SIGUSR1 to
# the main process. This handler reads the result file and exits accordingly.
handle_micom_result() {
  if [[ -f "$RESULT_FILE" ]]; then
    code=$(cat "$RESULT_FILE" || echo 1)
    if [[ "$code" -eq 0 ]]; then
      echo "[INFO] Post-micom checks passed; exiting with 0"
      exit 0
    else
      echo "[ERROR] Post-micom checks failed; exiting with 1"
      exit 1
    fi
  else
    echo "[ERROR] Post-micom signal received but no result file; failing"
    exit 1
  fi
}

trap 'handle_micom_result' SIGUSR1

# Function: run adb checks and compare builds, write result to $RESULT_FILE
do_post_micom_checks() {
  local marker="$1"
  # ensure marker exists for other consumers
  touch "$marker"
  echo "[INFO] micom stopped" | tee -a "$SERIAL_CAPTURE_LOG"
  echo "[INFO] Running adb checks and comparing builds..." | tee -a "$SERIAL_CAPTURE_LOG"

  if command -v adb >/dev/null 2>&1; then
    DBG="$CI_PROJECT_DIR/adb_debug.log"
    echo "---- adb debug: $(date +%Y-%m-%dT%H:%M:%S) ----" >> "$DBG" 2>&1 || true
    adb devices -l 2>&1 | tee -a "$DBG" || true
  fi

  if command -v adb >/dev/null 2>&1; then
    timeout 120 adb -s "${ADB_DEVICE_ID:-}" wait-for-device 2>/dev/null || true
  fi

  BUILD_AFTER=$(get_build_id)
echo "========================================"
echo "[INFO] BUILD COMPARISON (Before -> After)"
echo "========================================"
echo "[INFO] Build BEFORE flash: ${BUILD_BEFORE:-<none>}"
echo "[INFO] Build AFTER flash:  ${BUILD_AFTER:-<none>}"
echo "========================================" | tee -a "$SERIAL_CAPTURE_LOG"

  # decide result
  local rc=1
  if [[ -z "${BUILD_BEFORE:-}" && -z "${BUILD_AFTER:-}" ]]; then
echo "========================================"
echo "[ERROR] Could not obtain build ID!"
echo "[INFO] Build before: ${BUILD_BEFORE:-<none>}"
echo "[INFO] Build after:  ${BUILD_AFTER:-<none>}"
echo "[INFO] Treating as failed update."
echo "========================================" | tee -a "$SERIAL_CAPTURE_LOG"
    rc=1
  elif [[ "${BUILD_BEFORE}" == "${BUILD_AFTER}" ]]; then
echo "========================================"
echo "[ERROR] Flash update FAILED - Build unchanged!"
echo "[INFO] Current build: ${BUILD_AFTER:-unknown}"
echo "========================================" | tee -a "$SERIAL_CAPTURE_LOG"
    rc=1
  else
echo "========================================"
echo "[SUCCESS] Flash update completed!"
echo "[INFO] New build version: ${BUILD_AFTER:-unknown}"
echo "========================================" | tee -a "$SERIAL_CAPTURE_LOG"
    rc=0
  fi

  echo "$rc" > "$RESULT_FILE" || true
  # signal main script to read result and exit
  kill -s USR1 "$MAIN_PID" 2>/dev/null || true
}

# Helper: get build id from adb (returns empty string on failure)
get_build_id() {
  local id=""
  local dbg="$CI_PROJECT_DIR/adb_debug.log"
  if command -v adb >/dev/null 2>&1; then
    # record some adb context for debugging
    {
      echo "---- adb debug: $(date +%Y-%m-%dT%H:%M:%S) ----"
      adb version 2>&1 || true
      adb devices -l 2>&1 || true
    } >> "$dbg" 2>&1 || true

    local raw
    if [[ -n "${ADB_DEVICE_ID:-}" ]]; then
      raw=$(adb -s "$ADB_DEVICE_ID" shell getprop ro.build.display.id 2>&1 || true)
    else
      raw=$(adb shell getprop ro.build.display.id 2>&1 || true)
    fi
    # sanitize CRs
    id=$(echo "$raw" | tr -d '\r')

    if [[ -z "$id" ]]; then
      {
        echo "[DEBUG] adb getprop returned empty; full output below:" >> "$dbg"
        echo "$raw" >> "$dbg"
      } || true
      echo "[DEBUG] adb getprop returned empty; see $dbg for details"
    fi
  else
    echo "[DEBUG] adb command not found"
  fi
  echo "$id"
}

# Auto-select adb device from `adb devices -l` if not provided
# Target the device with product:cdc_r_ivi (Feature_VM_arm64)
if [[ -z "${ADB_DEVICE_ID:-}" ]]; then
  if command -v adb >/dev/null 2>&1; then
    # pick device with product:cdc_r_ivi
    SEL=$(adb devices -l 2>/dev/null | grep -E '\bdevice\b' | grep 'product:cdc_r_ivi' | awk '{print $1; exit}' || true)
    if [[ -n "$SEL" ]]; then
      ADB_DEVICE_ID="$SEL"
      DEV_LINE=$(adb devices -l 2>/dev/null | grep -E '\bdevice\b' | grep 'product:cdc_r_ivi' | head -n1 || true)
      echo "[INFO] Selected adb device: $ADB_DEVICE_ID ($DEV_LINE)"
    else
      echo "[WARN] No adb device found with product:cdc_r_ivi via 'adb devices -l'"
    fi
  fi
fi

# If we have an adb device id, attempt to run adbd as root and wait for device
if [[ -n "${ADB_DEVICE_ID:-}" ]] && command -v adb >/dev/null 2>&1; then
  echo "[INFO] Running 'adb -s $ADB_DEVICE_ID root' to restart adbd as root..."
  adb -s "$ADB_DEVICE_ID" root 2>/dev/null || true
  # wait a short while for adbd to restart
  adb -s "$ADB_DEVICE_ID" wait-for-device 2>/dev/null || true
  sleep 1
  echo "[INFO] adb device $ADB_DEVICE_ID should be ready (post-root)."
fi

if [[ -z "$USB_STICK_ID" ]]; then
  echo "[ERROR] USB_STICK_ID is not set. Set it via env/CI variables."
  exit 1
fi

if [[ -z "$TC_FILE" ]]; then
  echo "[ERROR] TC_FILE is not set. Set it via env/CI variables."
  exit 1
fi

# Capture build id from adb before starting rescue (may be empty)
BUILD_BEFORE=$(get_build_id)
echo "========================================"
echo "[INFO] CURRENT BUILD (Before Flash): ${BUILD_BEFORE:-<none>}"
echo "========================================"

# Ensure the rescue script exists before attempting to run it
if [[ ! -f "$RESCUE_SCRIPT" ]]; then
  echo "[ERROR] Rescue script not found: $RESCUE_SCRIPT"
  exit 1
fi

# Start rescue script and mirror output to serial capture log
stdbuf -oL bash "$RESCUE_SCRIPT" | tee "$SERIAL_CAPTURE_LOG" &
RESCUE_PID=$!
echo "[INFO] Started $RESCUE_SCRIPT (pid=$RESCUE_PID). Mirroring logs to $SERIAL_CAPTURE_LOG"


stdbuf -oL tail -n +1 -F "$SERIAL_CAPTURE_LOG" | sed -u 's/^/[SERIAL] /' &
FOLLOW_TAIL_PID=$!
echo "[INFO] Continuous serial follower started (pid=$FOLLOW_TAIL_PID)."

# Watcher: detect 10 consecutive "Waiting for calls... (Abort with CTRL+C)" lines
# If detected, stop the rescue (micom), touch a marker for post-processing
(
  COUNT=0
  THRESH=10
  MARKER="$CI_PROJECT_DIR/micom_stopped_by_watch"
  stdbuf -oL tail -n +1 -F "$SERIAL_CAPTURE_LOG" | while IFS= read -r _line; do
    line="$_line"
    if [[ "$line" == *"Waiting for calls... (Abort with CTRL+C)"* ]]; then
      COUNT=$((COUNT+1))
    else
      COUNT=0
    fi
    if [[ $COUNT -ge $THRESH ]]; then
      echo "[WARN] Detected $THRESH consecutive 'Waiting for calls...' lines. Stopping micom (rescue) ..."
      kill "$RESCUE_PID" 2>/dev/null || true
      # run post-micom checks now (this will write $RESULT_FILE and signal main)
      do_post_micom_checks "$MARKER"
      break
    fi
  done
) &


ROBOT_PID_FILE=$(mktemp)

# ----- WATCHER: wait for triggers and start Robot on each (once per trigger) -----
(
  TRIGGERED_MAIN=0
  TRIGGERED_ALT=0
  # Ensure pid file exists and is empty
  : > "$ROBOT_PID_FILE"

  # Tail the serial log and respond to trigger lines as they arrive.
  # For each trigger we start a robot run in background and record pid:log into $ROBOT_PID_FILE
  stdbuf -oL tail -n +1 -F "$SERIAL_CAPTURE_LOG" \
    | stdbuf -oL grep --line-buffered -a -F -e "$TRIGGER_SUBSTR" -e "$ALT_TRIGGER_SUBSTR" \
    | while IFS= read -r line; do
      if [[ "$line" == *"$TRIGGER_SUBSTR"* && $TRIGGERED_MAIN -eq 0 ]]; then
        TRIGGERED_MAIN=1
        TIMESTAMP=$(date +%Y%m%d-%H%M%S)
        LOG="${ROBOT_LOG%.log}-$TIMESTAMP.log"
        echo "[INFO] Main trigger seen. Starting Robot in background (log=$LOG)..."
        pushd /opt/rfw >/dev/null 2>&1 || pushd "$CI_PROJECT_DIR" >/dev/null 2>&1 || true
        poetry run robot \
          -v USB_STICK_ID:"${USB_STICK_ID}" \
          -v USB_STICK_MCH_PORT_ID:"${USB_STICK_MCH_PORT_ID}" \
          -v USB_STICK_PORT_ID:"${USB_STICK_PORT_ID}" \
          -v PHONE_USB_PORT_ID:"${PHONE_USB_PORT_ID}" \
          ${TC_FILE} \
          > "$LOG" 2>&1 &
        ROBOT_PID=$!
        popd >/dev/null 2>&1 || true
        echo "$ROBOT_PID:$LOG" >> "$ROBOT_PID_FILE"
        echo "[INFO] Robot launched (pid=$ROBOT_PID). Output -> $LOG"
      elif [[ "$line" == *"$ALT_TRIGGER_SUBSTR"* && $TRIGGERED_ALT -eq 0 ]]; then
        TRIGGERED_ALT=1
        TIMESTAMP=$(date +%Y%m%d-%H%M%S)
        LOG="${ROBOT_LOG%.log}-alt-$TIMESTAMP.log"
        echo "[INFO] ALT trigger seen. Starting Robot in background (log=$LOG)..."
        pushd /opt/rfw >/dev/null 2>&1 || pushd "$CI_PROJECT_DIR" >/dev/null 2>&1 || true
        poetry run robot \
          -v USB_STICK_ID:"${USB_STICK_ID}" \
          -v USB_STICK_MCH_PORT_ID:"${USB_STICK_MCH_PORT_ID}" \
          -v USB_STICK_PORT_ID:"${USB_STICK_PORT_ID}" \
          -v PHONE_USB_PORT_ID:"${PHONE_USB_PORT_ID}" \
          ${TC_FILE1} \
          > "$LOG" 2>&1 &
        ROBOT_PID=$!
        popd >/dev/null 2>&1 || true
        echo "$ROBOT_PID:$LOG" >> "$ROBOT_PID_FILE"
        echo "[INFO] ALT Robot launched (pid=$ROBOT_PID). Output -> $LOG"
      fi
      # If both triggers have fired once, stop watching
      if [[ $TRIGGERED_MAIN -eq 1 && $TRIGGERED_ALT -eq 1 ]]; then
        break
      fi
    done
) &

WATCHER_PID=$!
echo "[INFO] Watcher started (pid=$WATCHER_PID). Waiting for rescue.sh…"

# Read first robot pid:log entry (if any) and wait for that PID
FIRST_ENTRY=$(head -n1 "$ROBOT_PID_FILE" 2>/dev/null || echo "")
rm -f "$ROBOT_PID_FILE"
if [[ -n "$FIRST_ENTRY" ]]; then
  FIRST_PID=${FIRST_ENTRY%%:*}
  if [[ -n "$FIRST_PID" ]]; then
    wait "$FIRST_PID"
    echo "[INFO] Robot (pid=$FIRST_PID) completed. Exiting."
    exit 0
  fi
fi

# Wait for rescue process to finish (or be killed by the watcher)
wait "$RESCUE_PID"

# If the micom was stopped by the watcher, do adb checks and compare builds
MARKER="$CI_PROJECT_DIR/micom_stopped_by_watch"
if [[ -f "$MARKER" ]]; then
  rm -f "$MARKER"
  echo "[INFO] Detected micom stop marker. Checking adb for build id changes..."
  # dump adb devices output for debugging (appended to adb_debug.log and echoed)
  if command -v adb >/dev/null 2>&1; then
    DBG="$CI_PROJECT_DIR/adb_debug.log"
    echo "[DEBUG] dumping 'adb devices -l' to $DBG" | tee -a "$CI_PROJECT_DIR/adb_debug.log"
    adb devices -l 2>&1 | tee -a "$CI_PROJECT_DIR/adb_debug.log" || true
  fi
  # Wait for adb device to appear (timeout 120s)
  if command -v adb >/dev/null 2>&1; then
    timeout 120 adb -s "$ADB_DEVICE_ID" wait-for-device 2>/dev/null || true
  fi
  BUILD_AFTER=$(get_build_id)
  echo "========================================"
  echo "[INFO] BUILD COMPARISON (Before -> After)"
  echo "========================================"
  echo "[INFO] Build BEFORE flash: ${BUILD_BEFORE:-<none>}"
  echo "[INFO] Build AFTER flash:  ${BUILD_AFTER:-<none>}"
  echo "========================================"
    if [[ -z "${BUILD_BEFORE:-}" && -z "${BUILD_AFTER:-}" ]]; then
      echo "[ERROR] Could not obtain build id before or after; treating as no-update."
      exit 1
    fi
    if [[ "${BUILD_BEFORE}" == "${BUILD_AFTER}" ]]; then
    echo "========================================"
    echo "[ERROR] Flash update FAILED - Build unchanged!"
    echo "[INFO] Current build: ${BUILD_AFTER:-unknown}"
    echo "========================================"
    exit 1
      else
    echo "========================================"
    echo "[SUCCESS] Flash update completed!"
    echo "[INFO] New build version: ${BUILD_AFTER:-unknown}"
    echo "========================================"
    exit 0
    fi
fi