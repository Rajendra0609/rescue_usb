#!/bin/bash
set -e

export http_proxy="http://z040762:Rajyalakshm2026@cosmos-vip.intra.renault.fr:3128"
export https_proxy=$http_proxy
export HTTP_PROXY=$http_proxy
export HTTPS_PROXY=$http_proxy
export no_proxy=localhost,127.0.0.1,10.0.0.0/8,.tls.renault.fr,cosmos-vip.intra.renault.fr

# Function to print info messages
info() {
    echo "[INFO] $1"
}

# Function to print success messages
ok() {
    echo "[OK] $1"
}

# show branch
info "CCS3 tests branch: test/mch_switch"
# Clone CCS3 TESTS repository to required directory
info "Cloning CCS3 test repository..."
if [ ! -d /opt/rfw/ccs3 ]; then
	git clone -b test/mch_switch https://${ARTIFACTORY_UNPROTECTED_USERNAME}:${TOKEN_ACCESS}@gitlabee.dt.renault.com/sdv/domains/ccs/integration/modules/test_cases/extveh/tests.git /opt/rfw/ccs3
else
	info "/opt/rfw/ccs3 already exists — skipping clone"
fi
ok "CCS3 test repo clone completed."
