#!/usr/bin/env bash
# ============================================================
#  setup_env.sh  –  Manage environment variables for SW Rescue
#  Stores all values in .env (next to this script)
#  Run:  bash setup_env.sh
# ============================================================
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ENV_FILE="$SCRIPT_DIR/.env"

# ─── colour helpers ──────────────────────────────────────────
RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'
CYAN='\033[0;36m'; BOLD='\033[1m'; RESET='\033[0m'

info()    { echo -e "${CYAN}[INFO]${RESET}  $*"; }
ok()      { echo -e "${GREEN}[OK]${RESET}    $*"; }
warn()    { echo -e "${YELLOW}[WARN]${RESET}  $*"; }
section() { echo -e "\n${BOLD}${CYAN}═══ $* ═══${RESET}"; }

# ─── read current value from .env (empty string if missing) ──
current() {
    local key="$1"
    if [[ -f "$ENV_FILE" ]]; then
        grep -E "^${key}=" "$ENV_FILE" | head -n1 | cut -d'=' -f2- | sed "s/^['\"]//;s/['\"]$//" || true
    fi
}

# ─── write / update a key=value pair in .env ─────────────────
upsert() {
    local key="$1" value="$2"
    if [[ -f "$ENV_FILE" ]] && grep -qE "^${key}=" "$ENV_FILE"; then
        # replace existing line (portable sed)
        sed -i.bak "s|^${key}=.*|${key}=${value}|" "$ENV_FILE" && rm -f "${ENV_FILE}.bak"
    else
        echo "${key}=${value}" >> "$ENV_FILE"
    fi
}

# ─── prompt helper: shows current value, keeps it if user just hits ENTER ─
ask() {
    local key="$1" prompt="$2" default="$3" secret="${4:-false}"
    local cur; cur=$(current "$key")
    local display_default="${cur:-$default}"

    if [[ "$secret" == "true" && -n "$cur" ]]; then
        display_default="******* (set)"
    fi

    if [[ -n "$display_default" ]]; then
        echo -ne "  ${prompt} [${YELLOW}${display_default}${RESET}]: "
    else
        echo -ne "  ${prompt}: "
    fi

    local input
    if [[ "$secret" == "true" ]]; then
        read -rs input; echo
    else
        read -r input
    fi

    # Use input if provided; otherwise keep current value; otherwise use default
    local final="${input:-${cur:-$default}}"
    upsert "$key" "$final"
    echo "$final"
}

# ─── detect connected USB block devices ──────────────────────
detect_usb_dev() {
    local candidates=()
    for d in /dev/sda1 /dev/sdb1 /dev/sdc1 /dev/sdd1; do
        [[ -b "$d" ]] && candidates+=("$d")
    done
    if command -v lsblk >/dev/null 2>&1; then
        while IFS= read -r line; do
            candidates+=("$line")
        done < <(lsblk -nr -o PATH,TYPE,RM 2>/dev/null | awk '$2=="part" && $3==1 {print $1}')
    fi
    # deduplicate
    printf '%s\n' "${candidates[@]}" | sort -u | head -5
}

# ─── detect connected ADB devices ────────────────────────────
detect_adb_devices() {
    if command -v adb >/dev/null 2>&1; then
        adb devices -l 2>/dev/null | grep -E '\bdevice\b' | awk '{print $1}' || true
    fi
}

# ════════════════════════════════════════════════════════════
#  MAIN
# ════════════════════════════════════════════════════════════
clear
echo -e "${BOLD}${GREEN}"
echo "  ╔══════════════════════════════════════════════╗"
echo "  ║        SW Rescue – Environment Setup         ║"
echo "  ╚══════════════════════════════════════════════╝"
echo -e "${RESET}"

# Check if .env already exists
if [[ -f "$ENV_FILE" ]]; then
    warn ".env already exists at $ENV_FILE"
    echo -ne "  ${BOLD}Update existing values?${RESET} (press ENTER to keep current values) [Y/n]: "
    read -r confirm
    if [[ "${confirm,,}" == "n" ]]; then
        ok "No changes made. Exiting."
        exit 0
    fi
else
    info "Creating new .env file at $ENV_FILE"
    touch "$ENV_FILE"
fi

# ─── Section 1: Artifactory / Auth ───────────────────────────
section "Artifactory / Authentication"
ask "ARTIFACTORY_TOKEN_DT"             "Artifactory token (DT)"         ""          "true"
ask "ARTIFACTORY_UNPROTECTED_USERNAME" "Artifactory username (unprotected)" ""       "false"
ask "TOKEN_ACCESS"                     "GitLab / access token"          ""          "true"

# ─── Section 2: Docker Image ─────────────────────────────────
section "Docker Image"
ask "MATRIX_IMAGE_VERSION" "Matrix image version (e.g. 1.2.3)" "latest"

# ─── Section 3: Release / Rescue URL ─────────────────────────
section "Release URL"
echo -e "  ${YELLOW}Default:${RESET} generic-sdv_cdc-local/releases_dt/LGE/OFFICIAL/..."
ask "RESCUE_URL" \
    "Artifactory path (without base URL)" \
    "generic-sdv_cdc-local/releases_dt/LGE/OFFICIAL/RELEASE_S510_CDC_261.02.51_BL06.00/USERDEBUG/RESCUE_backup/Rescue_20260210_1526_USERDEBUG_UAT_blank_ORANGE.7z"

# ─── Section 4: USB ──────────────────────────────────────────
section "USB Device"
echo -e "  ${CYAN}Detected block devices:${RESET}"
mapfile -t usb_devs < <(detect_usb_dev)
if [[ ${#usb_devs[@]} -gt 0 ]]; then
    for d in "${usb_devs[@]}"; do echo "    • $d"; done
else
    echo "    (none detected – make sure USB is connected)"
fi
ask "USB_STICK_ID"         "USB Stick ID (label/serial)"  "087E-274D"
ask "USB_STICK_MCH_PORT_ID" "USB MCH port ID"              "1"
ask "USB_STICK_PORT_ID"    "USB Stick port ID"             "2"
ask "PHONE_USB_PORT_ID"    "Phone USB port ID"             "4"

# ─── Section 5: ADB ──────────────────────────────────────────
section "ADB Device (optional)"
echo -e "  ${CYAN}Detected ADB devices:${RESET}"
mapfile -t adb_devs < <(detect_adb_devices)
if [[ ${#adb_devs[@]} -gt 0 ]]; then
    for d in "${adb_devs[@]}"; do echo "    • $d"; done
else
    echo "    (none detected)"
fi
ask "ADB_DEVICE_ID" "ADB device serial (leave blank to auto-detect)" ""

# ─── Section 6: Mount point ──────────────────────────────────
section "Mount Point"
ask "MOUNT_POINT" "USB mount point inside container" "/mnt/Renault"

# ─── Section 7: CI project dir inside container ──────────────
section "Project"
ask "CI_PROJECT_DIR" "Project directory inside container" "/workspace"

# ─── Summary ─────────────────────────────────────────────────
echo
section "Saved Variables"
echo -e "  File: ${BOLD}$ENV_FILE${RESET}\n"
while IFS='=' read -r k v; do
    [[ "$k" =~ ^#.*$ || -z "$k" ]] && continue
    if [[ "$k" =~ TOKEN|PASSWORD|SECRET ]]; then
        echo -e "  ${CYAN}${k}${RESET} = ${YELLOW}*******${RESET}"
    else
        echo -e "  ${CYAN}${k}${RESET} = ${v}"
    fi
done < "$ENV_FILE"

echo
ok "Environment saved to $ENV_FILE"
info "Run  'docker-compose up'  to start the rescue job."
echo
