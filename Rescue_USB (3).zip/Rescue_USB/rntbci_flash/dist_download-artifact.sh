#!/bin/bash


export http_proxy="http://z040762:Rajyalakshm2026@cosmos-vip.intra.renault.fr:3128"
export https_proxy=$http_proxy
export HTTP_PROXY=$http_proxy
export HTTPS_PROXY=$http_proxy
export no_proxy=localhost,127.0.0.1,10.0.0.0/8,.tls.renault.fr,cosmos-vip.intra.renault.fr
JFROG_CLI_VERSION=${JFROG_CLI_VERSION:-"1.54.1"}
jfrog_version="jfrog-cli/$JFROG_CLI_VERSION/jfrog-cli-linux-amd64/jfrog"
DOWNLOAD_ARTI_TOKEN="$ARTIFACTORY_TOKEN_DT"
artifactory_dt="https://artifactory.dt.renault.com/artifactory"
if curl -sS -H "Authorization: Bearer $DOWNLOAD_ARTI_TOKEN" "$artifactory_dt"/"$jfrog_version" -o jfrog; then chmod +x ./jfrog; fi


TARGET_DIR="$CI_PROJECT_DIR/RescueBuild"
mkdir -p "$TARGET_DIR"

folder="$CI_PROJECT_DIR/RescueBuild"
release=$1

if [ $# -ne 1 ]; then
    read -p "Link to download without Artifactory URL: " release
fi


# Create the directory if it doesn't exist
mkdir -p "$folder"

echo "Folder path = $folder"
echo "Release URL is https://artifactory.dt.renault.com/artifactory/${release}"

file_d="Rescue_USERDEBUG_UAT.7z"



aria2c -x16 -s16 -k1M -c --file-allocation=none \
  --max-tries=10 --retry-wait=5 \
  --timeout=60 --connect-timeout=30 \
  --https-proxy="$https_proxy" \
  --header="X-JFrog-Art-Api: $DOWNLOAD_ARTI_TOKEN" \
  -d "$folder" -o "Rescue_USERDEBUG_UAT.7z" \
  "https://artifactory.dt.renault.com/artifactory/$release"

pushd $folder
ls -la

# Check if the downloaded file is a .7z archive and unzip it
if [[ "$file_d" == *.7z ]]; then
    7z x "$file_d"
    rm "$file_d"
fi
popd
