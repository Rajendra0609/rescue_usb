#!/usr/bin/env bash
set -euo pipefail

DEV="/dev/ttyUSB0"
BAUD="115200" 
qnx_shell() {
    local cmd="$1"
    sleep 0.2

    printf "%s\r\n" "$cmd" > "$DEV"
    
}
echo "Trigger rescue mode"

if [ ! -e "$DEV" ]; then
    echo "Error: Device $DEV not found (did you pass --device=/dev/ttyUSB0?)"
    exit 1
fi

chmod 666 "$DEV" || true

if command -v stty >/dev/null 2>&1; then
    stty -F "$DEV" "$BAUD" raw -echo -onlcr -ocrnl -ixoff -ixon -clocal || true
fi
echo "starting the TestApp.MicomCommunicationManager app"
qnx_shell "./mnt/app/bin/TestApp.MicomCommunicationManager"
echo "Go test command menu"
qnx_shell "4"
echo "vuc sleep request"
qnx_shell "01 11 01"
echo "entering rescue mode ..."
qnx_shell "4"
if command -v stdbuf >/dev/null 2>&1; then
    exec stdbuf -oL cat "$DEV"
else
    exec cat "$DEV"
fi